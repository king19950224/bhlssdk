using FxSDK.Codec;
using FxSDK.Models;
using FxSDK.Utility;
using NLog;

namespace FxSDK.Core;

/// <summary>
/// SDK和设备会话
/// </summary>
public abstract class IoSession
{
    private static readonly ILogger Logger = LogManager.GetCurrentClassLogger();

    public event EventHandler<EventArgs>? SessionConnected;
    public event EventHandler<SessionDisconnectedEventArgs>? SessionDisconnected;
    public event EventHandler<DecodedResultsReceivedEventArgs>? SessionDecResultsReceived;
    internal readonly FxProtocolHandler ProtocolHandler;
    private bool _disposed = false; // 添加一个标志
    protected IoSession(FxProtocolHandler protocolHandler)
    {
        ProtocolHandler = protocolHandler ?? throw new ArgumentNullException(nameof(protocolHandler));
    }

    /// <summary>
    /// 会话取消令牌（由派生类提供）
    /// </summary>
    protected abstract CancellationToken SessionToken { get; init; }

    /// <summary>
    /// 会话标识
    /// </summary>
    public string SessionId { get; protected set; }

    /// <summary>
    /// 心跳间隔（秒）
    /// </summary>
    protected static readonly double HeartbeatSeconds = 20;

    #region 触发事件
    protected void FireSessionConnected()
    {
        SessionConnected?.Invoke(this, EventArgs.Empty);
    }

    protected void FireSessionDisconnected(SessionCloseReason reason, Exception? ex = null)
    {
        SessionDisconnected?.Invoke(this, new SessionDisconnectedEventArgs(reason, ex));
    }

    internal void FireSessionDecodedResultReceived(DecodedResult[] batchResults)
    {
        SessionDecResultsReceived?.Invoke(this, new DecodedResultsReceivedEventArgs(batchResults));
    }
    #endregion

    /// <summary>
    /// 子类可重写以调整解码轮询间隔（默认 10ms）
    /// </summary>
    protected virtual int GetDecodeDelayMilliseconds() => 10;
    
    protected async Task DecodingLoop()
    {
        var delayMs = GetDecodeDelayMilliseconds();
    
        while (!SessionToken.IsCancellationRequested)
        {
            SessionToken.ThrowIfCancellationRequested();
            List<DecodedResult>? results = null;

            try
            {
                // 在独立 Task 中运行 TryDecode，带超时
                using var cts = CancellationTokenSource.CreateLinkedTokenSource(SessionToken);
                cts.CancelAfter(TimeSpan.FromMilliseconds(200)); // 最多 200ms
                var token = cts.Token;
                var decodeTask = Task.Run(() => ProtocolHandler.TryDecode(this,token), token);
                results = await decodeTask.ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (!SessionToken.IsCancellationRequested)
            {
                Logger.Warn("TryDecode timed out — possible infinite loop in DoDecode. Clearing context.");
                break;
            }
            catch (Exception e)
            {
                Logger.Error(e, "TryDecode threw exception");
                break;
            }

            if (results is {Count: > 0})
            {
                FireSessionDecodedResultReceived(results.ToArray());
            }

            try
            {
                await Task.Delay(delayMs, SessionToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }
    }

    /// <summary>
    /// 所有派生类必须调用
    /// </summary>
    internal virtual async Task OpenAsync()
    {
        FireSessionConnected();
    }

    private readonly SemaphoreSlim _sendLock = new(1, 1);

    internal async Task SendMsgAsync(IReadOnlyList<object> msgList)
    {
        await _sendLock.WaitAsync(SessionToken);
        try
        {
            foreach (var msg in msgList)
            {
                if (_disposed) return; // 检查是否已释放
                if (msg.Equals(FxUtility.Delay500Ms))
                    await Task.Delay(500, SessionToken);
                else if (msg.Equals(FxUtility.Delay100Ms))
                    await Task.Delay(100, SessionToken);
                else if (msg.Equals(FxUtility.Delay50Ms))
                    await Task.Delay(50, SessionToken);
                else if (msg.Equals(FxUtility.Delay10Ms))
                    await Task.Delay(10, SessionToken);
                else if (msg is byte[] bytes)
                    await SendDataAsync(bytes);
                else if (msg is List<byte> byteList)
                    await SendDataAsync(byteList.ToArray());
            }
        }
        catch (Exception ex)
        {
            Logger.Warn(ex, $"SendMsgAsync failed: {ex.Message}");
        }
        finally
        {
            _sendLock.Release();
        }
    }

    protected abstract Task SendDataAsync(byte[] data);

    public virtual Task CloseAsync()
    {
        try
        {
            ProtocolHandler.Dispose();
            // 清理 session 上下文
            SessionContext.ClearContext(this);
            // 解绑事件
            SessionConnected = null;
            SessionDisconnected = null;
            SessionDecResultsReceived = null;
        }
        catch (Exception ex)
        {
            Logger.Error(ex, $"IoSession.CloseAsync failed: {ex.Message}");
        }
        return Task.CompletedTask;
    }
}